# Installing your AI Employee

**Time: about five minutes. You do this once.**

You do not need to be technical. You do not need to write code. You are copying
some folders into the right place, and then talking to Claude normally.

---

## First, what you actually downloaded

Open the folder you unzipped. You have:

| | |
|---|---|
| `README.md` | Who this employee is and what they can do |
| `INSTALL.md` | This file |
| `TRAINING.md` | **Read this after installing.** How to actually work with them |
| `skills/` | The employee's capabilities — one folder each, plus two that come with every employee: `ai-coo` (the front door) and `business-brain` (the memory) |
| `upload-to-claude-ai/` | The same capabilities, zipped, for the Claude website |

A **skill** is a folder containing instructions Claude reads *only when it is
relevant*. That last part is the whole trick. You are not pasting a giant prompt
and hoping. You install once, then ask for what you want in plain English, and
Claude picks up the right instructions on its own.

You need a **paid Claude plan** (Pro or higher). Skills are not available on the
free tier.

---

## Choose your path

There are two ways to use Claude, and the install differs. **Pick one.** You can
do both later; doing both now just doubles the setup with no benefit.

- **Path A — the Claude website or desktop app.** Choose this if you have never
  opened a terminal and have no wish to start. This is most founders.
- **Path B — Claude Code.** Choose this if you are comfortable with a command
  line, or you want the employee to work with files on your computer.
- **Path C — ChatGPT.** Read the note under Path C before choosing it.

---

## Path A — Claude website or desktop app

1. Go to **claude.ai** and sign in, or open the Claude desktop app.
2. Open **Settings**, then find **Capabilities** (some accounts show this as
   **Features**). Find the **Skills** section.
3. Turn Skills on if there is a toggle, then choose **Upload skill**.
4. Upload the **first zip** from the `upload-to-claude-ai/` folder.
5. Repeat for each remaining zip. They go up one at a time.

> **Upload the zips from `upload-to-claude-ai/`, not the folders from
> `skills/`.** They contain the same thing, but the website wants a zip per
> skill. Zipping the whole download and uploading that will fail — it is one zip
> containing many skills, and the uploader expects one skill.

That is it. Nothing else to configure. Skip to **Check it worked**.

---

## Path B — Claude Code

**The quickest way is one command.** On this AI Employee's page in Client OS
(the page your download came from), choose **Get my install command**, copy
it, and paste it into a terminal:

- **Mac:** the Terminal app.
- **Linux:** any terminal.
- **Windows:** Git Bash, which comes with Git for Windows.

It puts every skill where Claude Code looks for them, puts the training guide
beside them in `~/.claude/surge`, and tells you what to do next. The command is
made for you and works for an hour: if it has expired, copy a fresh one from the
same page, and please do not share it.

**Want every AI Employee at once?** Choose **Install the whole team instead** on
the same page, or use the command at the top of the AI Employees page. One
command installs all of them, with an AI COO that knows the whole team.

**Or copy the folders by hand.** Copy the contents of `skills/` into your
Claude skills folder.

**Available everywhere, in every project:**

```bash
mkdir -p ~/.claude/skills && cp -R skills/* ~/.claude/skills/
```

**Or just this one project** — run from the project folder:

```bash
mkdir -p .claude/skills && cp -R skills/* .claude/skills/
```

On Windows without a Unix shell, copy the folders by hand: everything inside
`skills/` goes into `C:\Users\<you>\.claude\skills\`. The result must be
`~/.claude/skills/audit-my-business/SKILL.md` — the skill folder directly inside
`skills`, not another folder in between.

Restart Claude Code, or run `/doctor` in an existing session to pick them up.

---

## Path C — ChatGPT

Skills are a Claude mechanism: a folder Claude reads on its own when the work
calls for it. ChatGPT has no equivalent, so there the files are **project
material** rather than an install. What this pack contains is the method — the
markdown is the product — and ChatGPT can read it, but it will not pick the
right skill up by itself.

**What we have measured so far: nothing.** This path is written down so that it
is honest rather than implied. Until this paragraph changes, treat ChatGPT as
*unsupported*: it may work well, it may work poorly, and we have not run it end
to end. If you try it, the shape to try is a Project per employee with the
contents of `skills/` added as files and `ai-coo/SKILL.md`'s body pasted as the
Project instructions, then the same requests as `TRAINING.md` describes. Post
what you find in the community — that is how this paragraph gets replaced by a
measured one.

---

## Check it worked

Start a new conversation and ask:

> Who do I have on my team?

The AI COO — the front door that comes with every employee — answers with the
roster: which skills are installed here, and which live in an employee you have
not hired. If you see that, you are done — **open `TRAINING.md` next**, because
installing is the easy half and knowing how to brief the employee is what
actually produces good work.

Then, before anything else, the one interview you do once:

> Set up my business brain.

It writes `BUSINESS-BRAIN.md` — and every skill in every pack reads it first, so
nobody asks you to explain your business twice. On Claude Code the file lands in
your project folder; on the website it is a file you add to a Project (the skill
tells you). Keep it: if you upgrade to the Client Operating System, that file is
imported in one step.

---

## If it did not work

**Nothing is listed.**
Almost always one of three things. The folders went one level too deep — check
that `SKILL.md` sits *directly* inside each skill folder, not inside another
folder inside it. Or you are on the free plan, which does not have skills. Or
Claude Code has not been restarted.

**The install command says it has expired, or is not valid.**
Commands last an hour. Copy a fresh one from the AI Employee's page. If it says
your membership is not active, that page has the link to renew it.

**Claude answers but ignores the skill.**
Ask for the outcome, not the tool. "Audit my business" works. "Use the
audit-my-business skill" often does not, because you are naming a file rather
than describing a job. If it still will not engage, say plainly: *"Run your
business audit on my company"* — describing the work is what matches.

**It started, then produced something shallow.**
It asked you questions and you answered thinly, or it did not ask and you did
not offer. These skills are pipelines with a real onboarding stage; they are
built to interview you first. `TRAINING.md` covers how to feed them properly.

**Something else.**
Post in the community with what you tried, which path you chose, and what you
saw. Somebody has almost certainly hit it already.

---

## Keeping them up to date

These skills get improved. When a new version is announced, repeat the install.
Your conversations are unaffected whichever way you do it.

**Path B, with the install command:** run a fresh one. It updates every AI
Employee it has installed on that computer, and it keeps what you changed:

- A skill or training guide you edited, added a file to or deleted a file from
  is left exactly as you have it when the update has nothing new for it.
- When the update changes it too, your copy is moved into
  `~/.claude/surge/backups/` first and the new version goes in. The command
  names the folder, and gives you the line that compares the two.

It can tell because it records a checksum of every file it puts on your
computer, in `~/.claude/surge/checksums`. If you installed with the command
before it kept that record, the first update cannot tell yet: it keeps a copy
of everything that differs from the new version, once. To go back to Surge's
version of something you changed, move its folder out of the way and run a
fresh command.

**Path A, or copying the folders by hand:** nothing can tell what you changed,
so the new copy replaces yours. If you edited a skill, copy its folder somewhere
safe before you re-upload it or copy over the top.
