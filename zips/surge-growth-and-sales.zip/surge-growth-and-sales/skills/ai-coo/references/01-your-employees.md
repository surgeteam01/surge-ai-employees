# Module 1: Your employees

**Purpose:** The whole roster — four AI Employees, every skill each one holds, and which of those skills is installed in front of you right now. Route with this; never route from memory.

## The four AI Employees

Each employee is a job a founder already has a mental model for, and each skill inside it is a capability. A founder hires one at a time.

### The Business Strategist

*Hires for:* "I am busy every day and the business is not growing, and I cannot tell which of the ten things I could fix is the one that matters."

The one to hire first, because it tells you which employee to hire second.

| Skill | What it produces |
|---|---|
| `audit-my-business` | A whole-business diagnostic ending in a ranked list of what to fix, each item mapped to the skill that fixes it |
| `business-analyst` | One specific question answered rigorously from real data |
| `find-your-niche` | A specific, viable audience and positioning instead of "everyone" |
| `nail-your-pricing` | A defensible price — model, tiers, the actual number, margin-checked |
| `productize-your-service` | Bespoke, custom-quoted work turned into fixed-scope packages |
| `master-ai-prompting` | How to brief every other employee better |

### The Content Marketer

*Hires for:* "I know I should be posting consistently and I am not, because every time I sit down to write I have no idea what to say."

| Skill | What it produces |
|---|---|
| `write-like-a-human` | A reusable voice profile from real samples, and the AI tells stripped out |
| `30-days-of-content` | A month of platform-native content around themes that connect to the offer |
| `build-your-personal-brand-on-linkedin` | Profile, pillars, posts and an engagement system for LinkedIn |
| `grow-on-youtube` | Packaging, scripts, retention and search for a YouTube channel |
| `start-a-faceless-channel` | A video channel carried by narration and edit, no presenter |
| `launch-a-podcast` | Format, episode architecture, guest booking and the production workflow |
| `rank-on-google` | Search intent, keyword opportunity and the pages that answer them |

### The Growth & Sales Rep

*Hires for:* "I get some interest but it goes nowhere, and I have no repeatable way of turning a stranger into a paying client."

| Skill | What it produces |
|---|---|
| `get-more-leads-with-ai` | A capture, scoring and follow-up system rather than a lead magnet |
| `land-clients-with-cold-outreach` | Multi-touch cold outreach across email, LinkedIn and phone |
| `sales-page-that-converts` | A complete sales page that answers objections in a buyer's order |
| `build-your-email-funnel` | Welcome, nurture, sales and cart-close sequences |
| `write-better-ads` | Multi-angle paid ad campaigns built to be tested |
| `run-webinars-that-sell` | Registration through pitch through follow-up |

### The Brand & Product Builder

*Hires for:* "I have expertise people pay me for one hour at a time, and I want to turn it into something that sells without me in the room."

| Skill | What it produces |
|---|---|
| `build-your-own-brand-identity` | Personality, palette, type and logo direction as a usable brief |
| `create-ai-product-photos` | Shot lists, prompts and composition for AI-generated product imagery |
| `course-creator` | A course from curriculum through launch |
| `write-your-book` | A finished book or ebook manuscript from raw expertise |
| `launch-a-digital-product` | A live, evergreen or hybrid launch plan for a built product |
| `vibe-code-assistant` | Software built with AI assistance, for someone who is not a developer |

### In every pack

| Skill | What it produces |
|---|---|
| `ai-coo` | This — the front door |
| `business-brain` | The one interview, written to `BUSINESS-BRAIN.md`, that every other skill reads first |

## What is installed here

<!-- surge:installed-catalogue:begin -->
This copy of The AI COO was built into **The Growth & Sales Rep**. Every skill below is
either *installed in this pack* or lives in the employee named with it; a founder
hires that employee to get it. Do not guess at this list -- it was generated from
the packs themselves.

### The Business Strategist -- not installed; hire to get these

- `audit-my-business` -- lives in The Business Strategist
- `business-analyst` -- lives in The Business Strategist
- `find-your-niche` -- lives in The Business Strategist
- `nail-your-pricing` -- lives in The Business Strategist
- `productize-your-service` -- lives in The Business Strategist
- `master-ai-prompting` -- lives in The Business Strategist

### The Content Marketer -- not installed; hire to get these

- `30-days-of-content` -- lives in The Content Marketer
- `write-like-a-human` -- lives in The Content Marketer
- `build-your-personal-brand-on-linkedin` -- lives in The Content Marketer
- `grow-on-youtube` -- lives in The Content Marketer
- `start-a-faceless-channel` -- lives in The Content Marketer
- `launch-a-podcast` -- lives in The Content Marketer
- `rank-on-google` -- lives in The Content Marketer

### The Growth & Sales Rep -- installed in this pack

- `get-more-leads-with-ai` -- installed in this pack
- `land-clients-with-cold-outreach` -- installed in this pack
- `sales-page-that-converts` -- installed in this pack
- `build-your-email-funnel` -- installed in this pack
- `write-better-ads` -- installed in this pack
- `run-webinars-that-sell` -- installed in this pack

### The Brand & Product Builder -- not installed; hire to get these

- `build-your-own-brand-identity` -- lives in The Brand & Product Builder
- `create-ai-product-photos` -- lives in The Brand & Product Builder
- `course-creator` -- lives in The Brand & Product Builder
- `write-your-book` -- lives in The Brand & Product Builder
- `launch-a-digital-product` -- lives in The Brand & Product Builder
- `vibe-code-assistant` -- lives in The Brand & Product Builder

### In every pack

- `ai-coo` -- installed in this pack
- `business-brain` -- installed in this pack
- `design-your-ai-employee` -- installed in this pack
<!-- surge:installed-catalogue:end -->

## Foundational skills — run first when they are missing

Two skills sit under most others. `find-your-niche` decides who the work is for; `write-like-a-human` decides how it sounds. A founder with a `BUSINESS-BRAIN.md` that answers *target audience* and the *voice* part already has both; one without usually needs them before a content or sales skill will produce anything specific.

## Handoff

Module 2 asks the questions that make the request routable. Module 3 holds the journeys that cross employees. Module 4 is the hand-off itself, including what to say when the skill is not installed.
